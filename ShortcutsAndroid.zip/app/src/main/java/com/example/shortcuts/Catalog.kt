package com.example.shortcuts

data class Param(
    val key: String,
    val label: String,
    val def: String = "",
    val options: List<String>? = null,
    val multiline: Boolean = false
)

data class ActionDef(
    val type: String,
    val title: String,
    val category: String,
    val glyph: String,
    val desc: String,
    val params: List<Param> = emptyList(),
    val hasOutput: Boolean = true
)

private fun P(key: String, label: String, def: String = "", opts: List<String>? = null, ml: Boolean = false) =
    Param(key, label, def, opts, ml)

private fun A(
    type: String, title: String, cat: String, glyph: String, desc: String,
    vararg params: Param, out: Boolean = true
) = ActionDef(type, title, cat, glyph, desc, params.toList(), out)

val CatColors: Map<String, Long> = mapOf(
    "Scripting" to 0xFF8E8E93,
    "Lists & Data" to 0xFFF38A31,
    "Text" to 0xFFE0B000,
    "Numbers" to 0xFF29B6A5,
    "Dates" to 0xFFE5493A,
    "Web" to 0xFF2F80ED,
    "Device" to 0xFFD94A4A,
    "Apps" to 0xFF9B59B6,
    "Files" to 0xFFB5874A
)

object Catalog {
    private const val R = "{{Result}}"

    val all: List<ActionDef> = listOf(
        // ---------------- Scripting ----------------
        A("comment", "Comment", "Scripting", "💬", "Add a note to explain your shortcut",
            P("text", "Note", "", ml = true), out = false),
        A("nothing", "Nothing", "Scripting", "∅", "Pass nothing to the next action"),
        A("wait", "Wait", "Scripting", "⏳", "Pause the shortcut", P("seconds", "Seconds", "1"), out = false),
        A("stop", "Stop This Shortcut", "Scripting", "⛔", "Stop running this shortcut", out = false),
        A("output", "Stop and Output", "Scripting", "📤", "Stop and return a value to the caller",
            P("output", "Output", R), out = false),
        A("run_shortcut", "Run Shortcut", "Scripting", "▶️", "Run another shortcut by name",
            P("name", "Shortcut name", ""), P("input", "Input", R)),
        A("set_var", "Set Variable", "Scripting", "📥", "Save a value to use later",
            P("name", "Variable name", "x"), P("value", "Value", R), out = false),
        A("add_var", "Add to Variable", "Scripting", "➕", "Append a value to a list variable",
            P("name", "Variable name", "x"), P("value", "Value", R), out = false),
        A("get_var", "Get Variable", "Scripting", "📤", "Get a saved variable", P("name", "Variable name", "x")),
        A("ask_input", "Ask for Input", "Scripting", "⌨️", "Ask the user to type something",
            P("type", "Input type", "Text", listOf("Text", "Number")),
            P("prompt", "Prompt", "What is your input?"), P("default", "Default answer", "")),
        A("show_result", "Show Result", "Scripting", "🪧", "Show text in a dialog",
            P("text", "Text", R, ml = true), out = false),
        A("alert", "Show Alert", "Scripting", "⚠️", "Show an alert (Cancel stops the shortcut)",
            P("title", "Title", "Alert"), P("message", "Message", R),
            P("cancel", "Show Cancel button", "Yes", listOf("Yes", "No")), out = false),
        A("notification", "Show Notification", "Scripting", "🔔", "Post a notification",
            P("title", "Title", "Shortcuts"), P("body", "Body", R), out = false),
        A("if", "If", "Scripting", "🔀", "Run actions only if a condition is true",
            P("left", "Input", R),
            P("op", "Condition", "is", listOf("is", "is not", "contains", "does not contain", "begins with",
                "ends with", "is greater than", "is less than", "has any value", "has no value")),
            P("right", "Value", ""), out = false),
        A("else", "Otherwise", "Scripting", "🔀", "", out = false),
        A("endif", "End If", "Scripting", "🔀", "", out = false),
        A("repeat", "Repeat", "Scripting", "🔁", "Repeat the actions inside several times",
            P("count", "Times", "3"), out = false),
        A("repeat_each", "Repeat with Each", "Scripting", "🔂", "Run the actions for every item of a list",
            P("input", "List", R), out = false),
        A("endrepeat", "End Repeat", "Scripting", "🔁", "", out = false),
        A("menu", "Choose from Menu", "Scripting", "📋", "Let the user pick a path",
            P("prompt", "Prompt", "Choose one")),
        A("menu_item", "Menu Item", "Scripting", "▫️", "", P("title", "Title", "Item"), out = false),
        A("endmenu", "End Menu", "Scripting", "📋", "", out = false),

        // ---------------- Lists & Data ----------------
        A("list", "List", "Lists & Data", "🗒️", "Create a list (one item per line)",
            P("items", "Items", "", ml = true)),
        A("choose_list", "Choose from List", "Lists & Data", "☑️", "Pick one item of a list",
            P("input", "List", R), P("prompt", "Prompt", "Choose one")),
        A("count", "Count Items", "Lists & Data", "🔢", "Number of items in a list", P("input", "List", R)),
        A("get_item", "Get Item from List", "Lists & Data", "🎯", "First, last, random or numbered item",
            P("input", "List", R),
            P("which", "Item", "First Item", listOf("First Item", "Last Item", "Random Item", "Item At Index")),
            P("index", "Index", "1")),
        A("filter_list", "Filter List", "Lists & Data", "🧹", "Keep items that match a condition",
            P("input", "List", R),
            P("op", "Condition", "contains", listOf("is", "is not", "contains", "does not contain",
                "begins with", "ends with", "is greater than", "is less than")),
            P("value", "Value", "")),
        A("sort_list", "Sort List", "Lists & Data", "↕️", "Sort a list",
            P("input", "List", R),
            P("order", "Order", "A to Z", listOf("A to Z", "Z to A", "Smallest First", "Biggest First", "Random"))),
        A("dictionary", "Dictionary", "Lists & Data", "📖", "Create a dictionary (key: value per line)",
            P("items", "Items", "", ml = true)),
        A("get_dict", "Get Dictionary Value", "Lists & Data", "🔑", "Read a key (use a.b.0 for paths)",
            P("input", "Dictionary / JSON", R), P("key", "Key", "name")),
        A("set_dict", "Set Dictionary Value", "Lists & Data", "✏️", "Set a key in a dictionary",
            P("input", "Dictionary", R), P("key", "Key", "key"), P("value", "Value", "")),

        // ---------------- Text ----------------
        A("text", "Text", "Text", "🔤", "A piece of text (insert variables with the bar)",
            P("text", "Text", "", ml = true)),
        A("combine", "Combine Text", "Text", "🔗", "Join the items of a list",
            P("input", "List", R), P("separator", "Separator", ", ")),
        A("split", "Split Text", "Text", "✂️", "Split text into a list",
            P("input", "Text", R), P("separator", "Separator", ",")),
        A("replace", "Replace Text", "Text", "🔄", "Find and replace",
            P("input", "Text", R), P("find", "Find", ""), P("with", "Replace with", "")),
        A("match", "Match Text", "Text", "🧩", "Find matches of a regular expression",
            P("input", "Text", R), P("pattern", "Pattern", "[0-9]+")),
        A("case", "Change Case", "Text", "🅰️", "UPPERCASE, lowercase or Capitalize",
            P("input", "Text", R), P("mode", "Mode", "UPPERCASE", listOf("UPPERCASE", "lowercase", "Capitalize"))),
        A("count_text", "Count", "Text", "🔡", "Count characters, words or lines",
            P("input", "Text", R), P("what", "Count", "Characters", listOf("Characters", "Words", "Lines"))),
        A("url_encode", "URL Encode / Decode", "Text", "🔐", "Percent-encode text",
            P("input", "Text", R), P("mode", "Mode", "Encode", listOf("Encode", "Decode"))),
        A("base64", "Base64 Encode / Decode", "Text", "🧬", "Base64 conversion",
            P("input", "Text", R), P("mode", "Mode", "Encode", listOf("Encode", "Decode"))),
        A("speak", "Speak Text", "Text", "🗣️", "Read text out loud", P("text", "Text", R), out = false),

        // ---------------- Numbers ----------------
        A("number", "Number", "Numbers", "🔢", "A number", P("value", "Number", "0")),
        A("math", "Calculate", "Numbers", "➗", "Arithmetic on two numbers",
            P("a", "First", R), P("op", "Operation", "+", listOf("+", "-", "×", "÷", "mod")), P("b", "Second", "1")),
        A("expr", "Calculate Expression", "Numbers", "🧮", "Evaluate e.g. (2+3)*4/5",
            P("expression", "Expression", "")),
        A("stats", "Calculate Statistics", "Numbers", "📊", "Sum, average, min, max, median of a list",
            P("input", "List", R), P("op", "Operation", "Sum", listOf("Sum", "Average", "Minimum", "Maximum", "Median"))),
        A("random", "Random Number", "Numbers", "🎲", "Pick a random whole number",
            P("min", "Minimum", "1"), P("max", "Maximum", "100")),
        A("round", "Round Number", "Numbers", "🎚️", "Round a number",
            P("input", "Number", R), P("mode", "Mode", "Normal", listOf("Normal", "Round Up", "Round Down")),
            P("places", "Decimal places", "0")),

        // ---------------- Dates ----------------
        A("date", "Current Date", "Dates", "📅", "The current date and time"),
        A("format_date", "Format Date", "Dates", "🗓️", "Show a date in a chosen style",
            P("input", "Date", "{{Current Date}}"),
            P("style", "Style", "Medium", listOf("Short", "Medium", "Long", "Full", "Date Only", "Time Only", "ISO 8601", "Custom")),
            P("custom", "Custom format", "yyyy-MM-dd HH:mm")),
        A("adjust_date", "Adjust Date", "Dates", "⏩", "Add or subtract time",
            P("input", "Date", "{{Current Date}}"),
            P("op", "Operation", "Add", listOf("Add", "Subtract")), P("amount", "Amount", "1"),
            P("unit", "Unit", "Days", listOf("Minutes", "Hours", "Days", "Weeks", "Months", "Years"))),
        A("time_between", "Get Time Between Dates", "Dates", "⌛", "Difference between two dates",
            P("start", "From", "{{Current Date}}"), P("end", "To", ""),
            P("unit", "Unit", "Days", listOf("Minutes", "Hours", "Days", "Weeks"))),

        // ---------------- Web ----------------
        A("open_url", "Open URL", "Web", "🌐", "Open a link", P("url", "URL", "https://"), out = false),
        A("search_web", "Search Web", "Web", "🔎", "Search Google", P("query", "Query", R), out = false),
        A("fetch_url", "Get Contents of URL", "Web", "📡", "HTTP request (JSON becomes a dictionary)",
            P("url", "URL", "https://"),
            P("method", "Method", "GET", listOf("GET", "POST", "PUT", "DELETE")),
            P("headers", "Headers (Name: Value per line)", "", ml = true),
            P("body_type", "Request body", "None", listOf("None", "JSON", "Form", "Text")),
            P("body", "Body", "", ml = true)),

        // ---------------- Device ----------------
        A("device_detail", "Get Device Details", "Device", "📱", "Battery, model, screen, version…",
            P("detail", "Detail", "Battery Level", listOf("Battery Level", "Is Charging", "Device Model",
                "Manufacturer", "Android Version", "Screen Width", "Screen Height", "Language", "Time Zone"))),
        A("clipboard_get", "Get Clipboard", "Device", "📋", "Read the clipboard"),
        A("clipboard_set", "Copy to Clipboard", "Device", "📎", "Copy text", P("text", "Text", R), out = false),
        A("vibrate", "Vibrate Device", "Device", "📳", "Vibrate", P("ms", "Milliseconds", "300"), out = false),
        A("flashlight", "Set Flashlight", "Device", "🔦", "On, off or toggle",
            P("state", "State", "On", listOf("On", "Off", "Toggle")), out = false),
        A("set_volume", "Set Volume", "Device", "🔊", "Set a volume level (0–100)",
            P("stream", "Stream", "Media", listOf("Media", "Ring", "Alarm", "Notification")),
            P("level", "Level", "50"), out = false),
        A("set_ringer", "Set Ringer Mode", "Device", "🔕", "Normal, vibrate or silent",
            P("mode", "Mode", "Normal", listOf("Normal", "Vibrate", "Silent")), out = false),
        A("open_settings", "Open Settings", "Device", "⚙️", "Open a system settings page",
            P("page", "Page", "Wi-Fi", listOf("Wi-Fi", "Bluetooth", "Display", "Sound", "Battery", "Location",
                "Airplane Mode", "Apps", "Main settings")), out = false),

        // ---------------- Apps ----------------
        A("list_apps", "Get Installed Apps", "Apps", "🧰", "List launchable apps"),
        A("open_app", "Open App", "Apps", "🚪", "Open an app by name or package",
            P("app", "App name or package", "Settings"), out = false),
        A("share_text", "Share", "Apps", "📤", "Open the share sheet", P("text", "Text", R), out = false),
        A("call", "Call", "Apps", "📞", "Open the dialer", P("number", "Number", ""), out = false),
        A("sms", "Send Message", "Apps", "💬", "Compose an SMS",
            P("number", "To", ""), P("message", "Message", R), out = false),
        A("email", "Send Email", "Apps", "✉️", "Compose an email",
            P("to", "To", ""), P("subject", "Subject", ""), P("body", "Body", R), out = false),
        A("maps", "Show in Maps", "Apps", "📍", "Search a place", P("query", "Place", R), out = false),
        A("navigate", "Start Navigation", "Apps", "🧭", "Navigate to a destination",
            P("destination", "Destination", R), out = false),
        A("timer", "Start Timer", "Apps", "⏱️", "Timer in the clock app", P("seconds", "Seconds", "60"), out = false),
        A("alarm", "Create Alarm", "Apps", "⏰", "Alarm in the clock app",
            P("hour", "Hour (0-23)", "7"), P("minute", "Minute", "0"), P("label", "Label", ""), out = false),
        A("add_event", "Add Calendar Event", "Apps", "🗓️", "Create an event (dates as 2026-12-31 18:30)",
            P("title", "Title", ""), P("location", "Location", ""), P("start", "Starts", "{{Current Date}}"),
            P("end", "Ends", ""), P("notes", "Notes", ""), out = false),
        A("add_contact", "Create Contact", "Apps", "👤", "Create a contact",
            P("name", "Name", ""), P("phone", "Phone", ""), P("email", "Email", ""), out = false),

        // ---------------- Files ----------------
        A("select_file", "Select File", "Files", "📂", "Pick a file from Android Files and return its content URI"),
        A("open_app_file", "Open App with File", "Files", "📨", "Send the selected file to an app that supports importing it",
            P("app", "App name or package", ""), P("file", "Selected file", R),
            P("mode", "Send method", "Open File", listOf("Open File", "Share File")), out = false),
        A("run_shortcut_file", "Run Shortcut File", "Files", "📜", "Read and run a JSON shortcut/workflow file selected from device storage",
            P("file", "Shortcut file", R), P("input", "Input", "")),
        A("save_file", "Save File", "Files", "💾", "Save text in the app's Shortcuts folder",
            P("name", "File name", "note.txt"), P("content", "Content", R, ml = true),
            P("mode", "If exists", "Overwrite", listOf("Overwrite", "Append")), out = false),
        A("get_file", "Get File", "Files", "📄", "Read a text file from the Shortcuts folder",
            P("name", "File name", "note.txt")),
        A("delete_file", "Delete File", "Files", "🗑️", "Delete a file from the Shortcuts folder",
            P("name", "File name", "note.txt"), out = false)
    )

    val byType: Map<String, ActionDef> = all.associateBy { it.type }
    private val hidden = setOf("else", "endif", "endrepeat", "menu_item", "endmenu")
    val pickable: List<ActionDef> = all.filter { it.type !in hidden }
    val categories: List<String> = listOf("Scripting", "Lists & Data", "Text", "Numbers", "Dates", "Web", "Device", "Apps", "Files")

    fun newStep(type: String) = Step(
        type = type,
        params = byType[type]?.params?.associate { it.key to it.def } ?: emptyMap()
    )

    /** Steps inserted when the user adds an action (blocks come with their closers). */
    fun instantiate(type: String): List<Step> = when (type) {
        "if" -> listOf(newStep("if"), newStep("else"), newStep("endif"))
        "repeat" -> listOf(newStep("repeat"), newStep("endrepeat"))
        "repeat_each" -> listOf(newStep("repeat_each"), newStep("endrepeat"))
        "menu" -> listOf(newStep("menu"), newStep("menu_item").p("title", "Item 1"),
            newStep("menu_item").p("title", "Item 2"), newStep("endmenu"))
        else -> listOf(newStep(type))
    }
}

// ---------------- Automation triggers ----------------

data class AutoDef(val type: String, val title: String, val glyph: String, val params: List<Param>)

object AutoCatalog {
    val all: List<AutoDef> = listOf(
        AutoDef("time", "Time of Day", "⏰", listOf(
            P("hour", "Hour (0-23)", "8"), P("minute", "Minute", "0"),
            P("repeat", "Repeat", "Daily", listOf("Daily", "Weekly", "Monthly")),
            P("day", "Weekday (Weekly)", "Monday", listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")),
            P("dom", "Day of month (Monthly)", "1"))),
        AutoDef("charger", "Charger", "🔌", listOf(P("state", "When", "Connected", listOf("Connected", "Disconnected")))),
        AutoDef("battery", "Battery Level", "🔋", listOf(
            P("op", "When battery", "drops below", listOf("rises above", "drops below")), P("level", "Level %", "20"))),
        AutoDef("wifi", "Wi-Fi", "📶", listOf(P("state", "When", "Connected", listOf("Connected", "Disconnected")))),
        AutoDef("bluetooth", "Bluetooth", "🎧", listOf(P("state", "When a device", "Connects", listOf("Connects", "Disconnects")))),
        AutoDef("airplane", "Airplane Mode", "✈️", listOf(P("state", "When", "On", listOf("On", "Off")))),
        AutoDef("dnd", "Do Not Disturb", "🌙", listOf(P("state", "When", "On", listOf("On", "Off")))),
        AutoDef("lowpower", "Low Power Mode", "🪫", listOf(P("state", "When", "On", listOf("On", "Off")))),
        AutoDef("headphones", "Wired Headphones", "🎧", listOf(P("state", "When", "Plugged In", listOf("Plugged In", "Unplugged")))),
        AutoDef("unlock", "Device Unlocked", "🔓", emptyList())
    )
    val byType: Map<String, AutoDef> = all.associateBy { it.type }

    fun describe(a: Automation): String {
        val d = byType[a.type] ?: return a.type
        return when (a.type) {
            "time" -> {
                val h = (a.params["hour"] ?: "8").padStart(2, '0')
                val m = (a.params["minute"] ?: "0").padStart(2, '0')
                "$h:$m · ${a.params["repeat"] ?: "Daily"}"
            }
            "battery" -> "Battery ${a.params["op"] ?: ""} ${a.params["level"] ?: ""}%"
            "unlock" -> "Device unlocked"
            else -> d.title + ": " + (a.params["state"] ?: "")
        }
    }
}

// ---------------- Gallery ----------------

data class GalleryItem(val shortcut: Shortcut, val desc: String)

private fun st(type: String, vararg kv: Pair<String, String>): Step {
    val base = Catalog.newStep(type)
    return base.copy(params = base.params + kv)
}

private fun sc(name: String, color: Int, glyph: String, vararg steps: Step) =
    Shortcut(name = name, color = color, glyph = glyph, steps = steps.toList())

object Gallery {
    val starters: List<GalleryItem> = listOf(
        GalleryItem(sc("Say Hello", 5, "👋",
            st("ask_input", "prompt" to "What's your name?"),
            st("show_result", "text" to "Hello, {{Result}}!")), "Asks your name and greets you."),
        GalleryItem(sc("Battery Status", 3, "🔋",
            st("device_detail", "detail" to "Battery Level"),
            st("show_result", "text" to "Battery: {{Result}}%")), "Shows your battery level."),
        GalleryItem(sc("Flashlight", 2, "🔦", st("flashlight", "state" to "Toggle")), "Toggles the flashlight."),
        GalleryItem(sc("Quick Search", 6, "🔍",
            st("ask_input", "prompt" to "Search for?"), st("search_web")), "Ask for text and search the web.")
    )

    val categories: List<Pair<String, List<GalleryItem>>> = listOf(
        "Starter Shortcuts" to starters + listOf(
            GalleryItem(sc("Share Date", 7, "📅",
                st("date"), st("format_date", "style" to "Full"), st("share_text")), "Share today's date."),
            GalleryItem(sc("Timer 5 min", 4, "⏱️", st("timer", "seconds" to "300")), "Starts a 5 minute timer.")
        ),
        "Quick Actions" to listOf(
            GalleryItem(sc("Lowercase Clipboard", 10, "🅰️",
                st("clipboard_get"), st("case", "mode" to "lowercase"), st("clipboard_set"),
                st("notification", "title" to "Copied", "body" to "{{Result}}")), "Lowercases what you copied."),
            GalleryItem(sc("Roll a Die", 0, "🎲",
                st("random", "min" to "1", "max" to "6"),
                st("show_result", "text" to "You rolled {{Result}}")), "Random number from 1 to 6."),
            GalleryItem(sc("Coin Flip", 2, "🪙",
                st("list", "items" to "Heads\nTails"), st("get_item", "which" to "Random Item"),
                st("show_result")), "Heads or tails."),
            GalleryItem(sc("Wi-Fi Settings", 5, "📶", st("open_settings", "page" to "Wi-Fi")), "Jump to Wi-Fi settings.")
        ),
        "Get Organized" to listOf(
            GalleryItem(sc("Where To?", 8, "🧭",
                st("menu", "prompt" to "Where to?"),
                st("menu_item", "title" to "Maps"), st("maps", "query" to "coffee near me"),
                st("menu_item", "title" to "Search"), st("search_web", "query" to "weather today"),
                st("menu_item", "title" to "Settings"), st("open_settings", "page" to "Main settings"),
                st("endmenu")), "Pick a destination from a menu."),
            GalleryItem(sc("Buzz Three Times", 9, "📳",
                st("repeat", "count" to "3"), st("vibrate"), st("wait", "seconds" to "0.5"), st("endrepeat")),
                "Vibrates 3 times with a Repeat loop."),
            GalleryItem(sc("Word Counter", 4, "🔡",
                st("clipboard_get"), st("count_text", "what" to "Words"),
                st("show_result", "text" to "Words: {{Result}}")), "Counts the words you copied."),
            GalleryItem(sc("Quick Note", 3, "📝",
                st("ask_input", "prompt" to "Note?"),
                st("save_file", "name" to "notes.txt", "content" to "{{Current Date}}: {{Result}}\n", "mode" to "Append"),
                st("notification", "title" to "Saved", "body" to "Note added")), "Appends a dated note to notes.txt."),
            GalleryItem(sc("Date in 7 Days", 1, "⏩",
                st("date"), st("adjust_date", "amount" to "7"), st("format_date", "style" to "Long"),
                st("show_result")), "What date is it in a week?")
        ),
        "Data & Web" to listOf(
            GalleryItem(sc("Random Joke", 11, "😄",
                st("fetch_url", "url" to "https://official-joke-api.appspot.com/random_joke"),
                st("get_dict", "key" to "setup"), st("show_result")), "Fetches a joke from a web API."),
            GalleryItem(sc("My IP Address", 6, "🌐",
                st("fetch_url", "url" to "https://api.ipify.org?format=json"),
                st("get_dict", "key" to "ip"), st("show_result", "text" to "IP: {{Result}}")), "Shows your public IP."),
            GalleryItem(sc("Sum Numbers", 7, "➕",
                st("ask_input", "prompt" to "Numbers separated by commas"),
                st("split", "separator" to ","), st("stats", "op" to "Sum"),
                st("show_result", "text" to "Total: {{Result}}")), "Adds up a list of numbers."),
            GalleryItem(sc("Greet Each", 8, "🙋",
                st("list", "items" to "Ali\nSara\nOmar"),
                st("repeat_each"), st("notification", "title" to "Hello", "body" to "Hi {{Repeat Item}}!"),
                st("endrepeat")), "Repeat with Each over a list.")
        )
    )
}
