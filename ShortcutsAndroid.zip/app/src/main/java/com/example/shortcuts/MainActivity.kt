package com.example.shortcuts

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val incoming = mutableStateOf<Intent?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.load(applicationContext)
        incoming.value = intent
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        AutomationService.refresh(applicationContext)
        setContent { IosTheme { App(incoming) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        incoming.value = intent
    }
}

// ---------------- Navigation ----------------

sealed class Route {
    class Collection(val kind: String, val folderId: String? = null) : Route()
    class Editor(val id: String) : Route()
    class Details(val id: String) : Route()
    class Questions(val id: String) : Route()
    class Picker(val id: String) : Route()
    class AutoEdit(val id: String?) : Route()
    object Settings : Route()
}

class Nav(val stack: SnapshotStateList<Route>, val runner: (Shortcut, Any?) -> Unit) {
    var tab by mutableIntStateOf(0)
    var pendingImport by mutableStateOf<List<Shortcut>?>(null)
    var toastText by mutableStateOf<String?>(null)

    fun push(r: Route) { stack.add(r) }
    fun pop() { if (stack.isNotEmpty()) stack.removeAt(stack.size - 1) }
    fun run(sc: Shortcut, input: Any? = null) = runner(sc, input)

    fun importText(text: String): Boolean {
        return try {
            pendingImport = Store.parseImport(text)
            true
        } catch (e: Exception) {
            toastText = "That isn't a valid shortcut file"
            false
        }
    }
}

// ---------------- Run-time dialogs ----------------

sealed class Req {
    abstract val d: CompletableDeferred<String?>
    class Ask(val prompt: String, val default: String, val numeric: Boolean, override val d: CompletableDeferred<String?>) : Req()
    class Show(val title: String, val text: String, override val d: CompletableDeferred<String?>) : Req()
    class Choose(val prompt: String, val items: List<String>, override val d: CompletableDeferred<String?>) : Req()
    class Confirm(val title: String, val text: String, val cancel: Boolean, override val d: CompletableDeferred<String?>) : Req()
}

class UiController : RunUi {
    var req by mutableStateOf<Req?>(null)
    var launchFilePicker: (() -> Unit)? = null
    private var pendingFile: CompletableDeferred<String?>? = null

    override suspend fun pickFile(): String? {
        val deferred = CompletableDeferred<String?>()
        pendingFile = deferred
        val launch = launchFilePicker
        if (launch == null) {
            pendingFile = null
            throw IllegalStateException("File picker is not available")
        }
        launch()
        return deferred.await()
    }

    fun completeFilePick(uri: Uri?) {
        pendingFile?.complete(uri?.toString())
        pendingFile = null
    }

    override suspend fun ask(prompt: String, default: String, numeric: Boolean): String? {
        val d = CompletableDeferred<String?>()
        req = Req.Ask(prompt, default, numeric, d)
        return d.await()
    }

    override suspend fun show(title: String, text: String) {
        val d = CompletableDeferred<String?>()
        req = Req.Show(title, text, d)
        d.await()
    }

    override suspend fun choose(prompt: String, items: List<String>): String? {
        val d = CompletableDeferred<String?>()
        req = Req.Choose(prompt, items, d)
        return d.await()
    }

    override suspend fun confirm(title: String, message: String, showCancel: Boolean): Boolean {
        val d = CompletableDeferred<String?>()
        req = Req.Confirm(title, message, showCancel, d)
        return d.await() != null
    }
}

@Composable
fun RunDialogs(ui: UiController) {
    val r = ui.req ?: return
    fun close(v: String?) {
        ui.req = null
        r.d.complete(v)
    }
    when (r) {
        is Req.Ask -> {
            var t by remember(r) { mutableStateOf(r.default) }
            AlertDialog(
                onDismissRequest = { close(null) },
                title = { Text(r.prompt) },
                text = {
                    OutlinedTextField(
                        value = t, onValueChange = { t = it },
                        keyboardOptions = KeyboardOptions(keyboardType = if (r.numeric) KeyboardType.Number else KeyboardType.Text)
                    )
                },
                confirmButton = { TextButton(onClick = { close(t) }) { Text("Done") } },
                dismissButton = { TextButton(onClick = { close(null) }) { Text("Cancel") } }
            )
        }
        is Req.Show -> AlertDialog(
            onDismissRequest = { close("") },
            title = { Text(r.title) },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(r.text) } },
            confirmButton = { TextButton(onClick = { close("") }) { Text("Done") } }
        )
        is Req.Choose -> AlertDialog(
            onDismissRequest = { close(null) },
            title = { Text(r.prompt) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    r.items.forEach { item -> TextButton(onClick = { close(item) }) { Text(item) } }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { close(null) }) { Text("Cancel") } }
        )
        is Req.Confirm -> {
            if (r.cancel) {
                AlertDialog(
                    onDismissRequest = { close(null) },
                    title = { Text(r.title) },
                    text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(r.text) } },
                    confirmButton = { TextButton(onClick = { close("ok") }) { Text("OK") } },
                    dismissButton = { TextButton(onClick = { close(null) }) { Text("Cancel") } }
                )
            } else {
                AlertDialog(
                    onDismissRequest = { close("ok") },
                    title = { Text(r.title) },
                    text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(r.text) } },
                    confirmButton = { TextButton(onClick = { close("ok") }) { Text("OK") } }
                )
            }
        }
    }
}

// ---------------- Root ----------------

@Composable
fun App(incoming: MutableState<Intent?>) {
    val ctx = LocalContext.current
    val appCtx = ctx.applicationContext
    val scope = rememberCoroutineScope()
    val ui = remember { UiController() }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        ui.completeFilePick(uri)
    }
    ui.launchFilePicker = { filePicker.launch(arrayOf("*/*")) }
    val stack = remember { mutableStateListOf<Route>() }
    var runningName by remember { mutableStateOf<String?>(null) }
    var job by remember { mutableStateOf<Job?>(null) }
    var shareInput by remember { mutableStateOf<String?>(null) }

    val nav = remember {
        Nav(stack) { sc, input ->
            job = scope.launch {
                runningName = sc.name
                try {
                    Interpreter(appCtx, ui).run(sc, input)
                    Toast.makeText(appCtx, "\"${sc.name}\" finished", Toast.LENGTH_SHORT).show()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    ui.show("Shortcut failed", e.message ?: e.toString())
                } finally {
                    runningName = null
                }
            }
        }
    }

    val toast = nav.toastText
    LaunchedEffect(toast) {
        if (toast != null) {
            Toast.makeText(appCtx, toast, Toast.LENGTH_SHORT).show()
            nav.toastText = null
        }
    }

    LaunchedEffect(incoming.value) {
        val i = incoming.value ?: return@LaunchedEffect
        if (i.getBooleanExtra("handled", false)) return@LaunchedEffect
        i.putExtra("handled", true)
        val data: Uri? = i.data
        when {
            i.action == Intents.ACTION_RUN -> {
                val sc = i.getStringExtra(Intents.EXTRA_ID)?.let { Store.get(it) }
                    ?: i.getStringExtra(Intents.EXTRA_NAME)?.let { Store.byName(it) }
                if (sc != null) nav.run(sc, null) else nav.toastText = "Shortcut not found"
            }
            i.action == Intent.ACTION_VIEW && data != null && data.scheme == "shortcuts" -> {
                val name = data.getQueryParameter("name") ?: ""
                when (data.host) {
                    "run-shortcut" -> {
                        val sc = Store.byName(name)
                        if (sc != null) nav.run(sc, data.getQueryParameter("input")) else nav.toastText = "Shortcut not found: $name"
                    }
                    "open-shortcut" -> Store.byName(name)?.let { nav.push(Route.Editor(it.id)) }
                    "create-shortcut" -> {
                        val s = Shortcut(name = name.ifBlank { "New Shortcut" }, color = Store.items.size % TileColors.size)
                        Store.add(s)
                        nav.push(Route.Editor(s.id))
                    }
                    "gallery" -> { stack.clear(); nav.tab = 2 }
                }
            }
            i.action == Intent.ACTION_VIEW && data != null -> {
                try {
                    val text = appCtx.contentResolver.openInputStream(data)?.bufferedReader()?.use { it.readText() } ?: ""
                    nav.importText(text)
                } catch (e: Exception) {
                    nav.toastText = "Could not read that file"
                }
            }
            i.action == Intent.ACTION_SEND -> {
                val text = i.getStringExtra(Intent.EXTRA_TEXT)
                val stream: Uri? = streamExtra(i)
                shareInput = text ?: stream?.toString() ?: ""
            }
        }
    }

    val top = stack.lastOrNull()
    BackHandler(enabled = stack.isNotEmpty()) { nav.pop() }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Box(Modifier.fillMaxSize()) {
            when (top) {
                null -> HomeScreen(nav)
                is Route.Collection -> CollectionScreen(nav, top)
                is Route.Editor -> EditorScreen(nav, top.id)
                is Route.Details -> DetailsScreen(nav, top.id)
                is Route.Questions -> QuestionsScreen(nav, top.id)
                is Route.Picker -> PickerScreen(nav, top.id)
                is Route.AutoEdit -> AutomationEditScreen(nav, top.id)
                is Route.Settings -> SettingsScreen(nav)
            }

            val rn = runningName
            if (rn != null) {
                Card(Modifier.align(Alignment.BottomCenter).padding(bottom = 90.dp, start = 16.dp, end = 16.dp).fillMaxWidth()) {
                    Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Running \"$rn\"…", Modifier.weight(1f))
                        TextButton(onClick = { job?.cancel(); ui.req?.d?.complete(null); ui.req = null; runningName = null }) { Text("Stop") }
                    }
                }
            }
        }
        RunDialogs(ui)

        val imp = nav.pendingImport
        if (imp != null) ImportDialog(imp, onDone = { nav.pendingImport = null; if (it) nav.toastText = "Imported" })

        val si = shareInput
        if (si != null) ShareChooser(si, nav, onClose = { shareInput = null })
    }
}

@Suppress("DEPRECATION")
private fun streamExtra(i: Intent): Uri? =
    if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
    else i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
